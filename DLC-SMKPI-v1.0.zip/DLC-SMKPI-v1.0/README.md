# DLC SMKPI v1.0
Milestone 1.
Buka index.html atau upload ke GitHub Pages.
